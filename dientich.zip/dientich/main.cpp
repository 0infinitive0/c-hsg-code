#include <bits/stdc++.h>

using namespace std;
int toado[2001][2001];
int n,maxs=0;
int kq=0;

void dtich(int w,int x,int y,int z)
{
   for(int i=w+1000;i<y+1000;i++)
    for(int j=x+1000;j<z+1000;j++)
       if(toado[i][j]!= 1)
       {
           kq++;
           toado[i][j]=1;
       }
       return;
}

struct Interval
{
    int bx, by, tx, ty;
};
 Interval mat [1000];

main()
{
    freopen("dientich.inp","r",stdin);
    cin>> n;
    for(int i=0;i<n;i++)
    {
        cin>> mat[i].bx>> mat[i].by>> mat[i].tx>> mat[i].ty;
    }
    memset(toado,0,sizeof(toado));
    for(int o=0;o<n;o++)
    {
        dtich(mat[o].bx, mat[o].by, mat[o].tx, mat[o].ty);
    }
    cout<<kq;
    return 0;
}

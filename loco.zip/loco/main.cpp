#include <bits/stdc++.h>
#define int unsigned long long

using namespace std;
int n,m,k;
vector<int> easy;
void check()
{
    for(int i=1;i<4;i++)
        if(easy[i]>=m) easy[i]=easy[i]%m;
}
void moves()
{
    for(int i=0;i<3;i++)
        easy[i]=easy[i+1];
}
int up()
{
    moves();
    easy[3]=0;
    for(int i=0;i<3;i++)
        easy[3]+=easy[i];
    easy[3]=easy[3]%m;
}


main()
{
    freopen("loco.inp","r",stdin);
    freopen("test2.txt","w",stdout);
    cin >> n >> m;
    easy.resize(4);
    easy[1]=1; easy[2]=2; easy[3]=4;
    if(n<4)
    {
        k=easy[n]%m;
    } else
    {
        check();
        for(int i=4;i<=n;i++)
            up();
        k=easy[3];
    }
    cout << k;


    return 0;
}

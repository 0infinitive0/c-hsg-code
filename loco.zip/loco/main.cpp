#include <bits/stdc++.h>
#define int unsigned long long

using namespace std;
int n,m,k;
int qhd[5][1001];

int des(int x,int y)
{
    int &kq=qhd[y][x];
    kq=des(x,y-1);
    if(y<2)
    {
        qhd[y][x]=x-y+1;
        return x-y+1;
    }
    if(qhd[y][x]!=0) return qhd[y][x];
    kq=0;
    if(x-y<0)return 0;
    while(x>=y)
    {
        x=x-y;
        kq += des(x,y-1);
    }
    return kq;
}

main()
{
    freopen("loco.inp","r",stdin);
    freopen("test2.txt","w",stdout);
    cin >> n >> m;
    memset(qhd,0,sizeof(qhd));
    while(n>0)
    {
        k+=des(n,3);
        n=n-3;
    }
    cout << k << endl;
    cout << qhd[2][5]<<endl;
   for(int i=0;i<5;i++)
    {
        for(int j=0;j<1001;j++)
            cout << qhd[i][j]<<" ";
        cout <<endl;
    }

    return 0;
}

#include <iostream>
#include <bits/stdc++.h>
#define int unsigned long long

using namespace std;
int n,k,l;
int qhd[101][1001];

int des(int x,int y)
{
    int &kq=qhd[y][x];
    if(y<2)return 1;
    if(qhd[y][x]!=0) return qhd[y][x];
    kq=0;
    kq=des(x,y-1);
    while(x>=y)
    {
        x=x-y;
        kq += des(x,y-1);
    }
    return kq;
}


main()
{
    freopen("change.inp","r",stdin);
    freopen("test2.txt","w",stdout);
    cin >> k >> n;
    memset(qhd,0,sizeof(qhd));
    cout << des(k,n) << endl;
   for(int i=0;i<101;i++)
    {
        for(int j=0;j<1001;j++)
            cout << qhd[i][j]<<" ";
        cout <<endl;
    }

    return 0;
}

#include <iostream>
#include <bits/stdc++.h>

using namespace std;
long int n,k,l;
long int kq=1;
void des(long int x,long int y)
{
    if(y>2){des(x,y-1);}
    while(x>=y)
    {
        x=x-y;
        if(y>2){des(x,y-1);}
        kq++;

    }

}


int main()
{
    freopen("change.inp","r",stdin);
    freopen("test2.txt","w",stdout);
    cin >> k >> n;
    des(k,n);
    cout << kq;
    return 0;
}

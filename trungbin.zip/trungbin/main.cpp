#include <iostream>
#include <bits/stdc++.h>

using namespace std;
long long int n,k;
long long int kq=0;
vector<long long int> arr;

bool dodai(long long int x,long long int y )
{
    if((n-x)<y){return false;}
    else
    {
        long long int sosanh = k*x;
        long long int sum=0 ;
        for(int i=y;i<y+x;i++)
            sum += arr[i];
        if(sum == sosanh){return true;}
        else
        {
            if(dodai(x,y+1)==true){return true;}
            else {return false;}
        }
    }
}

int main()
{
    freopen("average.inp","r",stdin);
    freopen("average.out","w",stdout);
    cin >> n >> k ;
    arr.resize(n);
    for(int i=0;i<n;i++)
        cin >> arr[i];
    for(int i=n;i>0;i--)
    {
        if(dodai(i,0)==true)
        {
            kq=i;
            break;
        }
    }
    cout << kq << endl;
    return 0;
}

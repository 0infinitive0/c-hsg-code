#include <bits/stdc++.h>
#define int long long
using namespace std;
vector<int> what;
string chu;

void tonum(char x)
{
    string lama = "IVXLCDM";
    vector<int> vals = {1, 5, 10, 50, 100, 500, 1000};
    for(int i=0;i<7;i++)
        if(x==lama[i])
        {
            what.push_back(vals[i]);
            break;
        }
}
int lama()
{
    int sum=what[what.size()-1];
    for(int i=what.size()-1;i>0;i--)
        if(what[i-1]>=what[i])
        {sum+=what[i-1];}
    else{sum-=what[i-1];}
    return sum;
}

main()
{
    freopen("lama.inp","r",stdin);
    freopen("lama.out","w",stdout);
    cin>>chu;
    for(int i=0;i<chu.size();i++)
        tonum(chu[i]);
    cout<<lama();
    return 0;
}

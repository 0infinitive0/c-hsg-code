#include <bits/stdc++.h>
#define int long long

using namespace std;
int n,k,kq;
vector<int> hoc;

void dem(int x)
{
    int sum=0;
    for(int i=0;i<=n-x;i++)
    {
        sum=0;
        for(int j=i;j<(i+x);j++)
            sum+=hoc[j];
        if(sum>=k)
        {
            kq=x;
            return ;
        }
    }
    if(x<=n)
    {
        dem(x+1);
    }
}

main()
{
    freopen("luyentap.inp","r",stdin);
    freopen("luyentap.out","w",stdout);
    cin>> n >> k;
    hoc.resize(n);
    for(int i=0;i<n;i++)
        cin>>hoc[i];
    kq=-1;
    dem(1);
    cout<<kq;
    return 0;
}

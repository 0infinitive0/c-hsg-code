#include <iostream>
#include <bits/stdc++.h>

using namespace std;
int n,k;
int kq=0;
vector<vector<int>> maps;
bool doi(vector<vector<int>> x)
{
    int sum=0;
    for(int i=0;i<n;i++)
        sum= sum+ (x[i][0]*x[i][1]);
    if(sum==k){return true;}
    else {return false;}
}

int main()
{

    freopen("change.inp","r",stdin);
    freopen("test.txt","w",stdout);
    cin >> k >> n;
    maps.resize(n);
    for(int i=0;i<n;i++)
    {
        maps[i].resize(2);
        maps[i][0]=i+1;
        maps[i][1]=0;
    }

    do
    {

        maps[0][1]++;
        for(int i=0;i<n-1;i++)
        {

            if((maps[i][1]*maps[i][0])>k)
            {
                maps[i][1]=0;
                maps[i+1][1]++;
            }
        }



        if(doi(maps)==true){kq++;}
    } while (maps[n-1][1]<=k);
    cout << kq << endl;
    return 0;
}

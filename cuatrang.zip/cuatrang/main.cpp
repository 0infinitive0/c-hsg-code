#include <bits/stdc++.h>
#define endl "\n"
#define uint unsigned long long int
#define fori(i,n,m) for(uint i = n; i < m; i++)
using namespace std;

uint n, m;
vector<uint> tsnt(1, 0);
vector<uint> arr(1, 0);
vector<uint> ngto = {2};
void split_tsnt(uint n) {
    uint i = 0;
    while (n != 1) {
        bool check = false;
        while(n % ngto[i] != 0) {
            if (check) ngto[ngto.size()-1]++;
            else if (ngto.size()-1 == i) {
                ngto.push_back(ngto[ngto.size()-1]);
                check = true;
                ++i;
            } else ++i;
        }
        tsnt[ngto[i]]++;
        n /= ngto[i];
    }
}
void split_m(uint n) {
    uint i = 0;
    while (n != 1) {
        bool check = false;
        while(n % ngto[i] != 0) {
            if (check) ngto[ngto.size()-1]++;
            else if (ngto.size()-1 == i) {
                ngto.push_back(ngto[ngto.size()-1]);
                check = true;
                ++i;
            } else ++i;
        }
        arr[ngto[i]]++;
        n /= ngto[i];
    }
}

main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    freopen("cuatrang.inp", "r", stdin);
    freopen("cuatrang.out", "w", stdout);
    cin>>n>>m;
    tsnt.resize(max(n,m)+1);
    arr.resize(m+1);

    fori(i, 2, n+1) {
        split_tsnt(i);
    }
    split_m(m);
    uint amin = 0;
    fori (i, 2, m+1) {
        if (arr[i] == 0) continue;
        uint t = tsnt[i] / arr[i];
        if (t < amin || amin == 0) amin = t;
    }
    cout<<amin;

    return 0;
}

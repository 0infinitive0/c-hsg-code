#include <bits/stdc++.h>
#define int long long;

using namespace std;
int n,k,c;

vector<vector<int>> hoa;
void go()
{
    int o=0;
    if(hoa[x][o]!=0)
    {
        o++;
        hoa[x].insert(hoa[x].end(),hoa[x][0]);
    }
}

int main()
{

    cin>>n>>k>>c;
    hoa.resize(n+1);
    for(int i=0;i<n;i++)
    {
        hoa[i+1].resize(1);
        cin>>hoa[i+1][0];
    }

    cout << "Hello world!" << endl;
    return 0;
}

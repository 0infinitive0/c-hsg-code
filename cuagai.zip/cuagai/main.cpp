#include <bits/stdc++.h>
#define int long long
#define endl "\n"

using namespace std;
int n,k,c;

vector<vector<int>> hoa;
bool compare(vector<int> s, vector<int> s2) {
    return (s.size() > s2.size());
}

void go(int x,int y)
{
    if((hoa[x][y]!=0)&&(hoa[hoa[x][y]][1]!=x))
    {
        hoa[x].resize(y+2);
        hoa[x][y+1]=hoa[hoa[x][y]][1];
        go(x,y+1);
    } else return;
}

main()
{
    freopen("cuagai.inp","r",stdin);
    cin>>n>>k>>c;
    hoa.resize(n+1);
    for(int i=0;i<n;i++)
    {
        hoa[i+1].resize(2);
        cin>>hoa[i+1][1];
        hoa[i+1][0]=i+1;
    }
    for(int i=1;i<=n;i++)
    {
        go(i,1);
        hoa[i].erase (hoa[i].begin()+(hoa[i].size()-1));
    }
    sort(hoa.begin(), hoa.end(), compare);
    int o=0;
    while(o<=hoa.size())
    {
        o++;
        for(int i=1;i<hoa[o].size();i++)
            for(int j=1;j<hoa.size()-1;j++)
                if(hoa[j][0]==hoa[o][i])
        {
            hoa.erase(hoa.begin()+j);
            break;
        }
    }


    for(int i=1;i<=n;i++)
    {
        for(auto &a: hoa[i])
            cout << a<<" ";
     //   cout<< hoa[i].size();
        cout<<endl;
    }

    cout << "Hello world!" << endl;
    return 0;
}

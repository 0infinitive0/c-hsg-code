
#include <bits/stdc++.h>

using namespace std;
#define SIZE 600
int n;
int minx,miny;
int maxx,maxy;
struct Interval
{
    int x, y;
};
Interval vuon[600];

bool compare(Interval s, Interval s2) {
    return (s.x < s2.x);
}

int main()
{
    minx=0; miny=0; maxx=1000; maxy=1000;
    freopen("vuontao.inp","r",stdin);
    freopen("vuontao.out","w",stdout);
    cin >> n ;
    for (int i=0;i<n;i++)
        cin >> vuon[i].x >> vuon[i].y;
    for (int i=0;i<n;i++)
    {
        if (min(min((vuon[i].x-minx),(vuon[i].y-miny)),min((maxx-vuon[i].x),(maxy-vuon[i].y))) < 0)
            continue;
            if(min((vuon[i].x-minx),(vuon[i].y-miny)) < min((maxx-vuon[i].x),(maxy-vuon[i].y)))
            {
                if((vuon[i].x-minx) < (vuon[i].y-miny))
                {minx = vuon[i].x;}
                else {miny = vuon[i].y;}
            } else
            {
                if((maxx-vuon[i].x) < (maxy-vuon[i].y))
                {maxx = vuon[i].x;}
                else {maxy = vuon[i].y;}
            }
    }
    sort(vuon, vuon+n, compare);
    //for (int i=0;i<n;i++)
    long int S = (maxx-minx)*(maxy-miny);
    cout << S << endl;
    cout << minx <<" " << miny << endl;
    cout << maxx <<" " << maxy << endl;
    return 0;
}

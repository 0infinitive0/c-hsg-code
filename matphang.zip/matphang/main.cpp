#include <string>
#include <bits/stdc++.h>
#include <iostream>

using namespace std;
int n;
vector<vector<string>> bando;
struct Interval
{
    int tx, ty, bx, by;
};
Interval mat[30];

string to_string(int n) {
    stringstream ss;
    ss << n;
    return ss.str();
}

void virus(string a,int x,int y)
{
    string t=a;

    if(bando[x+1][y]==a)
    {
        bando[x][y]="X";
        virus(t,x+1,y);
    }
    if(bando[x-1][y]==a)
    {
        bando[x][y]="X";
        virus(t,x-1,y);
    }
    if(bando[x][y-1]==a)
    {
        bando[x][y]="X";
        virus(t,x,y-1);
    }
    if(bando[x][y+1]==a)
    {
        bando[x][y]="X";
        virus(t,x,y+1);
    }
    bando[x][y]="X";
}

int main()
{
    freopen("matphang.inp","r",stdin);
    //freopen("bando.inp","w",stdout);
    cin >> n ;
    for (int i=0;i<n;i++)
    {
        cin >> mat[i].bx >> mat[i].by >> mat[i].tx >> mat[i].ty;
        mat[i].bx=mat[i].bx*2+1;
        mat[i].tx=mat[i].tx*2+1;
        mat[i].by=mat[i].by*2+1;
        mat[i].ty=mat[i].ty*2+1;
    }

    int maxi=0;
    for (int i=0;i<n;i++)
    {
        if(maxi<max(max(mat[i].tx,mat[i].ty),max(mat[i].bx,mat[i].by)))
            maxi = max(max(mat[i].tx,mat[i].ty),max(mat[i].bx,mat[i].by));
    }
        bando.resize(maxi+1);
    for (int i = 0; i <= maxi; ++i)
    bando[i].resize(maxi+1);

    for (auto &i : bando)
    fill(i.begin(), i.end(), "X");
    for(int i=0;i<n;i++)
    {
        for(int j=mat[i].bx;j<mat[i].tx;j++)
        {
            for(int k=mat[i].by;k<mat[i].ty;k++)
        {
        bando[j][k]=bando[j][k]+to_string(i);
        }}}
    int dem=0;
    for(int j=0;j<maxi;j++)
    {
            for(int k=0;k<maxi;k++)
                if(bando[j][k]!="X")
                {
                    virus(bando[j][k],j,k);
                    dem++;
                }

    }
    cout << dem;
    return 0;
}
